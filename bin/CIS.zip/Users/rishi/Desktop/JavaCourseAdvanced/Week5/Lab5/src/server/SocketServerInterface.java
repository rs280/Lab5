package server;

public interface SocketServerInterface
{
    boolean listen();
    void close();
}
