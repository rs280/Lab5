package adapter;

public interface ProxyAutoException {

}
