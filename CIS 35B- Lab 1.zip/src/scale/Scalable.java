package scale;

public interface Scalable {
	public void Operation(int opnumber, String[] input);
}